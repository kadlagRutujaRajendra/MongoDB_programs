var express = require('express');
const app = express();
var bodyParser = require('body-parser');
var collection = require('./logdb');

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({ extended: false }));

app.get('/', (req, res) => {
    res.render('login');
})

app.get('/register', (req, res) => {
    res.render('register');
})

app.post('/reg', (req, res) => {
    const data = {
        name: req.body.name,
        email: req.body.email,
        mobile: req.body.mobile,
        password: req.body.password,
    }

    collection.insertMany([data])

    res.redirect("register");
})

app.post('/log', async(req, res) => {
    try{
    const check = await collection.findOne({ email: req.body.email })
        if (check.password===req.body.password) {
            res.render("logpage");
        }
        else {
            res.send("Invalid Password");
        }
    }
    catch(error){
        console.log("Invalid Details"+error)
    }

})

app.listen(9880, () => {
    console.log("login system started on port 9880");
})